/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test;

import static manejoArchivos.manejoArchivos.*;

/**
 *
 * @author Hell
 */
public class testManejoArchivos {
    public static void main(String[]args){
        var nombreArchivo = "prueba.txt";
        
    //    crearArchivo(nombreArchivo);
    //    escribirArchivo(nombreArchivo, "Hola desde Java");
    //    escribirArchivo(nombreArchivo, "Juancito");
    //    anexarArchivo(nombreArchivo, "Hola desde Java");
    //    anexarArchivo(nombreArchivo, "Anexar");
        
        leerArchivo(nombreArchivo);
    }
}
